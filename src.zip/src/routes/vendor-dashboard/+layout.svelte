<!-- src/routes/vendor-dashboard/+layout.svelte -->
<script>
  import VendorHeader from '$features/vendorDashboard/components/VendorHeader.svelte';
</script>

<VendorHeader />

<slot />