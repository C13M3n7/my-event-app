<!-- src/routes/vendor-dashboard/+layout.svelte -->
<script>
  import AdminHeader from '$features/adminDashboard/components/AdminHeader.svelte';
</script>

<AdminHeader />

<slot />