<script>
    import VendorForm from '$features/adminDashboard/components/VendorForm.svelte';
  </script>
  
  <VendorForm />