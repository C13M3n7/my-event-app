<!-- Admin Analytics Page -->
<script>
    import Analytics from '$features/adminDashboard/components/Analytics.svelte';
  </script>
  
  <Analytics />
  