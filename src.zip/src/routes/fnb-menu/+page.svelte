<!-- src\routes\fnb-menu\+page.svelte -->
<script lang="ts">
  export let data;
  import VendorCard from '$features/fnb/components/VendorCard.svelte';
  import FilterButton from '$features/fnb/components/FilterButton.svelte';
  
  let searchQuery = '';
  
  $: filteredVendors = data.vendors.filter(vendor => 
    vendor.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    vendor.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
    (vendor.features && vendor.features.toLowerCase().includes(searchQuery.toLowerCase())) ||
    (vendor.categories && vendor.categories.toLowerCase().includes(searchQuery.toLowerCase()))
  );
</script>

<div class="min-h-screen bg-gradient-to-b from-blue-50 to-white">
  <header class="bg-white shadow-sm">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div class="flex flex-col md:flex-row md:items-center md:justify-between">
        <div class="flex-1 min-w-0">
          <h1 class="text-3xl font-bold text-gray-900 flex items-center">
            <span class="mr-3">🍽️</span>
            Vendors in HFF2025
          </h1>
          <p class="mt-2 text-sm text-gray-500">
            Browse our selection of vendors
          </p>
        </div>
        
        <div class="mt-4 flex md:mt-0 md:ml-4 space-x-3">
          <div class="relative flex-1 min-w-[200px]">
            <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <svg class="h-5 w-5 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
              </svg>
            </div>
            <input
              type="text"
              bind:value={searchQuery}
              placeholder="Search vendors..."
              class="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
            />
          </div>
          
          <FilterButton onClick={() => alert('Filter functionality coming soon')} />
        </div>
      </div>
    </div>
  </header>

  <main class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
    <div class="grid gap-6 sm:grid-cols-1 md:grid-cols-2 lg:grid-cols-1">
      {#if filteredVendors.length > 0}
        {#each filteredVendors as vendor}
          <VendorCard 
            id={vendor.id}
            name={vendor.name}
            description={vendor.description}
            rating={vendor.rating}
            image={vendor.image}
            features={vendor.features}
            categories={vendor.categories}
          />
        {/each}
      {:else}
        <div class="text-center py-12 col-span-full">
          <svg xmlns="http://www.w3.org/2000/svg" class="mx-auto h-12 w-12 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
          </svg>
          <h3 class="mt-2 text-lg font-medium text-gray-900">
            No vendors found
          </h3>
          <p class="mt-1 text-sm text-gray-500">
            {searchQuery 
              ? 'Try adjusting your search query'
              : 'No vendors available at this time'}
          </p>
        </div>
      {/if}
    </div>
  </main>
</div>