import { getVendors } from '$features/fnb/services/fnbService';
import type { PageLoad } from './$types';

export const load: PageLoad = async () => {
  const vendors = await getVendors();
  
  // Transform data to match frontend expectations
  const transformedVendors = vendors.map(vendor => ({
    id: vendor.id,
    name: vendor.business_name,
    description: vendor.description,
    rating: vendor.rating || 4.0, // Default rating if not provided
    image: vendor.image_url,
    features: vendor.features || '',
    categories: vendor.categories || ''
  }));

  return {
    vendors: transformedVendors
  };
};