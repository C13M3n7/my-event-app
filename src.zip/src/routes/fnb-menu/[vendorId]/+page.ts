import { getVendors } from '$features/fnb/services/fnbService';

export async function load() {
  const vendors = await getVendors();
  return { vendors };
}