<!-- src/routes/auth/login/+page.svelte -->
<script lang="ts">
    import Login from '../../../features/authentication/components/Login.svelte';
  </script>
  
  <div class="min-h-screen flex items-center justify-center  bg-gray-50">
    <Login />
  </div>