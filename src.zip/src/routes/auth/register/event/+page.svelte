<!-- Event Registration -->
<script>
    import RegisterEvent from '$features/authentication/components/RegisterEvent.svelte';
  </script>
  
  <RegisterEvent />