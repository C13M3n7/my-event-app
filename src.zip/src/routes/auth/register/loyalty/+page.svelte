<!-- Loyalty Registration -->
<script>
    import RegisterLoyalty from '$features/authentication/components/RegisterLoyalty.svelte';
  </script>
  
  <RegisterLoyalty />