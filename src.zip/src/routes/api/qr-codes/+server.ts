import { error, json } from '@sveltejs/kit';
import QRCode from 'qrcode';
import { VENDOR_BASE_URL } from '$env/static/private';
import type { RequestHandler } from './$types.js'; // Added .js extension

export const GET: RequestHandler = async ({ url, locals }) => {
    // Verify vendor authentication
    if (!locals.vendor) throw error(401, 'Unauthorized');
    
    const table = url.searchParams.get('table');
    if (!table || !/^[A-Z0-9]{1,4}$/i.test(table)) {
        throw error(400, 'Invalid table number');
    }

    try {
        const menuUrl = `${VENDOR_BASE_URL}/fnb-menu/${locals.vendor.id}?table=${table}`;
        
        const qrCode = await QRCode.toDataURL(menuUrl, {
            width: 400,
            margin: 2,
            color: {
                dark: '#1E40AF', // Blue-800
                light: '#FFFFFF'
            }
        });
        
        return json({ 
            qrCode, 
            table,
            menuUrl,
            generatedAt: new Date().toISOString()
        });
    } catch (err) {
        throw error(500, 'Failed to generate QR code');
    }
}