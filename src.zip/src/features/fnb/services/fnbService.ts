import { db } from '$lib/firebase';
import { 
  collection, 
  getDocs, 
  getDoc, 
  doc, 
  addDoc,
  serverTimestamp,
  writeBatch,
  query,
  orderBy,
  limit,
  startAfter,
  where
} from 'firebase/firestore';
import { 
  getStorage, 
  ref, 
  uploadBytes, 
  getDownloadURL,
  deleteObject 
} from 'firebase/storage';
import imageCompression from 'browser-image-compression';
import type { Vendor, VendorFormData } from '../types/vendor';

const storage = getStorage();
const VENDOR_IMAGE_PATH_PREFIX = 'vendors';

class VendorServiceError extends Error {
  constructor(message: string, public code: string, public originalError?: unknown) {
    super(message);
    this.name = 'VendorServiceError';
  }
}

// Helper function to get image URL
async function getImageUrl(imagePath: string): Promise<string> {
  try {
    if (!imagePath) return '/images/fallback-vendor.png';
    if (imagePath.startsWith('http')) return imagePath;
    return await getDownloadURL(ref(storage, imagePath));
  } catch (error) {
    console.error('Error getting image URL:', error);
    return '/images/fallback-vendor.png';
  }
}

const validateStoragePath = (path: string) => {
  if (!path.startsWith(`${VENDOR_IMAGE_PATH_PREFIX}/`)) {
    throw new VendorServiceError(
      `Storage path must start with '${VENDOR_IMAGE_PATH_PREFIX}/'`,
      'INVALID_STORAGE_PATH'
    );
  }
};

// Image handling
export const uploadVendorImage = async (file: File): Promise<string> => {
  try {
    const storagePath = `${VENDOR_IMAGE_PATH_PREFIX}/${Date.now()}-${file.name}`;
    validateStoragePath(storagePath);
    
    const storageRef = ref(storage, storagePath);
    const metadata = {
      cacheControl: 'public, max-age=31536000', // 1 year cache
    };
    
    await uploadBytes(storageRef, file, metadata);
    return await getDownloadURL(storageRef);
  } catch (error) {
    console.error('Error uploading vendor image:', error);
    throw new VendorServiceError(
      'Failed to upload image',
      'IMAGE_UPLOAD_ERROR',
      error
    );
  }
};

export const uploadOptimizedImage = async (file: File): Promise<string> => {
  try {
    const options = {
      maxSizeMB: 1,
      maxWidthOrHeight: 1920,
      useWebWorker: true
    };
    const compressedFile = await imageCompression(file, options);
    return await uploadVendorImage(compressedFile);
  } catch (error) {
    console.error('Image compression error:', error);
    throw new VendorServiceError(
      'Failed to optimize image',
      'IMAGE_COMPRESSION_ERROR',
      error
    );
  }
};

// Vendor operations
export const checkDuplicateVendor = async (businessName: string): Promise<boolean> => {
  try {
    const q = query(
      collection(db, 'vendors'),
      where('business_name', '==', businessName),
      limit(1)
    );
    const snapshot = await getDocs(q);
    return !snapshot.empty;
  } catch (error) {
    console.error('Error checking duplicate vendor:', error);
    throw new VendorServiceError(
      'Failed to check duplicate vendor',
      'DUPLICATE_CHECK_ERROR',
      error
    );
  }
};

export const createVendor = async (vendorData: VendorFormData): Promise<string> => {
  try {
    const isDuplicate = await checkDuplicateVendor(vendorData.business_name);
    if (isDuplicate) {
      throw new VendorServiceError(
        'Vendor with this name already exists',
        'DUPLICATE_VENDOR'
      );
    }

    const docRef = await addDoc(collection(db, 'vendors'), {
      ...vendorData,
      created_at: serverTimestamp(),
      updated_at: serverTimestamp()
    });
    return docRef.id;
  } catch (error) {
    console.error('Error creating vendor:', error);
    throw error instanceof VendorServiceError 
      ? error 
      : new VendorServiceError(
          'Failed to create vendor',
          'VENDOR_CREATION_ERROR',
          error
        );
  }
};

export const addVendor = async (
  formData: VendorFormData, 
  imageFile: File | null
): Promise<string> => {
  try {
    let imageUrl = '';
    
    if (imageFile) {
      imageUrl = await uploadOptimizedImage(imageFile);
    }

    return await createVendor({
      ...formData,
      image_url: imageUrl
    });
  } catch (error) {
    console.error('Error adding vendor:', error);
    throw error;
  }
};

// Get operations
export const getVendors = async (): Promise<Vendor[]> => {
  try {
    const vendorsCol = collection(db, 'vendors');
    const vendorSnapshot = await getDocs(vendorsCol);
    
    const vendorsWithImages = await Promise.all(
      vendorSnapshot.docs.map(async doc => {
        const data = doc.data();
        return {
          id: doc.id,
          ...data,
          image_url: await getImageUrl(data.image_url),
          created_at: data.created_at?.toDate() || new Date(),
          updated_at: data.updated_at?.toDate() || new Date()
        } as Vendor;
      })
    );
    
    return vendorsWithImages;
  } catch (error) {
    console.error('Error fetching vendors:', error);
    throw new VendorServiceError(
      'Failed to fetch vendors',
      'VENDORS_FETCH_ERROR',
      error
    );
  }
};

export const getVendorsPaginated = async (
  limitCount: number,
  lastDoc?: any
): Promise<{ vendors: Vendor[]; lastVisible: any | null }> => {
  try {
    let q = query(
      collection(db, 'vendors'),
      orderBy('created_at'),
      limit(limitCount)
    );

    if (lastDoc) {
      q = query(q, startAfter(lastDoc));
    }

    const snapshot = await getDocs(q);
    const vendors = await Promise.all(
      snapshot.docs.map(async doc => {
        const data = doc.data();
        return {
          id: doc.id,
          ...data,
          image_url: await getImageUrl(data.image_url),
          created_at: data.created_at?.toDate() || new Date()
        } as Vendor;
      })
    );

    return {
      vendors,
      lastVisible: snapshot.docs[snapshot.docs.length - 1] || null
    };
  } catch (error) {
    console.error('Error fetching paginated vendors:', error);
    throw new VendorServiceError(
      'Failed to fetch paginated vendors',
      'PAGINATED_VENDORS_ERROR',
      error
    );
  }
};

export const getVendorInfo = async (vendorId: string): Promise<Vendor | null> => {
  try {
    const vendorDoc = await getDoc(doc(db, 'vendors', vendorId));
    if (!vendorDoc.exists()) return null;
    
    const data = vendorDoc.data();
    return {
      id: vendorDoc.id,
      ...data,
      image_url: await getImageUrl(data.image_url),
      created_at: data.created_at?.toDate() || new Date(),
      updated_at: data.updated_at?.toDate() || new Date()
    } as Vendor;
  } catch (error) {
    console.error('Error fetching vendor:', error);
    throw new VendorServiceError(
      'Failed to fetch vendor',
      'VENDOR_FETCH_ERROR',
      error
    );
  }
};

// Batch operations
export const updateMultipleVendors = async (updates: Array<{
  id: string;
  data: Partial<Vendor>;
}>): Promise<void> => {
  try {
    const batch = writeBatch(db);
    
    updates.forEach(update => {
      const docRef = doc(db, 'vendors', update.id);
      batch.update(docRef, {
        ...update.data,
        updated_at: serverTimestamp()
      });
    });

    await batch.commit();
  } catch (error) {
    console.error('Error updating multiple vendors:', error);
    throw new VendorServiceError(
      'Failed to update vendors',
      'BATCH_UPDATE_ERROR',
      error
    );
  }
};