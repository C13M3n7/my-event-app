<script lang="ts">
  export let id: string;
  export let name: string;
  export let description: string;
  export let rating: number;
  export let image: string;
  export let features: string | undefined;
  export let categories: string | undefined;
  
  const handleImageError = (e: Event) => {
    const img = e.target as HTMLImageElement;
    img.src = '/images/fallback-vendor.png';
    img.classList.replace('object-cover', 'object-contain');
  };
</script>

<a 
  href={`/fnb-menu/${id}`} 
  class="block bg-white rounded-xl shadow-md hover:shadow-lg transition-all duration-300 overflow-hidden border border-gray-200 hover:border-blue-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
>
  <div class="flex flex-col sm:flex-row h-full">
    <!-- Standardized Image -->
    <div class="w-full sm:w-1/3 h-48 sm:h-auto bg-gray-100">
      <img
        src={image}
        alt={name}
        class="w-full h-full object-cover"
        on:error={handleImageError}
      />
    </div>
    
    <!-- Vendor Info -->
    <div class="w-full sm:w-2/3 p-4 sm:p-6 flex flex-col">
      <div class="flex justify-between items-start">
        <h2 class="text-xl font-bold text-gray-900 line-clamp-2">{name}</h2>
        <div class="flex items-center bg-white/90 px-2 py-1 rounded-full text-sm font-semibold">
          ★ {rating.toFixed(1)}
        </div>
      </div>
      
      <p class="text-gray-600 mt-2 text-sm line-clamp-3 flex-grow">{description}</p>
      
      <!-- {#if features || categories}
        <div class="mt-3 pt-3 border-t border-gray-100 text-sm">
          {#if features}
            <div class="text-gray-500 line-clamp-1">
              <span class="font-medium">Features:</span> {features}
            </div>
          {/if}
          {#if categories}
            <div class="text-gray-500 line-clamp-1 mt-1">
              <span class="font-medium">Categories:</span> {categories}
            </div>
          {/if}
        </div>
      {/if} -->
    </div>
  </div>
</a>

<style>
  /* Removed unused .line-clamp-1 rule */
  .line-clamp-2 {
    display: -webkit-box;
    -webkit-line-clamp: 2;
    line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
  }
  .line-clamp-3 {
    display: -webkit-box;
    -webkit-line-clamp: 3;
    line-clamp: 3;
    -webkit-box-orient: vertical;
    overflow: hidden;
  }
</style>