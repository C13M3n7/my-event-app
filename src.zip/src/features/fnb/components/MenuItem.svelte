<!-- Display invidual menu item -->
<script lang="ts">
  export let item;
  export let onAdd;
  export let onRemove;
</script>

<div class="bg-white rounded-lg overflow-hidden shadow-sm hover:shadow-md transition-shadow">
  <div class="relative aspect-square overflow-hidden">
    <img 
      src={item.image} 
      alt={item.title} 
      class="w-full h-full object-cover"
      on:error={() => item.image = '/images/fallback-food.png'}
    />
    <div class="absolute inset-0 bg-gradient-to-t from-black/30 to-transparent flex flex-col justify-end p-2">
      <h4 class="text-white font-semibold text-sm line-clamp-1">{item.title}</h4>
    </div>
  </div>
  
  <div class="p-2">
    <div class="flex items-center justify-between">
      <p class="font-bold text-gray-900 text-sm">RM {item.price.toFixed(2)}</p>
      <div class="flex items-center space-x-2">
        <button 
          class="w-6 h-6 flex items-center justify-center bg-gray-100 text-gray-800 rounded-full hover:bg-gray-200 disabled:opacity-50 transition-colors active:scale-95"
          on:click={onRemove} 
          disabled={item.quantity <= 0}
          aria-label="Decrease quantity"
        >
          −
        </button>
        <span class="text-sm font-medium min-w-[1rem] text-center">{item.quantity || 0}</span>
        <button 
          class="w-6 h-6 flex items-center justify-center bg-gray-100 text-gray-800 rounded-full hover:bg-gray-200 transition-colors active:scale-95"
          on:click={onAdd}
          aria-label="Increase quantity"
        >
          +
        </button>
      </div>
    </div>
  </div>
</div>