export interface MenuItem {
    id: string;
    title: string;
    image: string;
    category: string;
    price: number;
    vendorId: string;
    vendorName: string;
    description?: string;
    variants?: {
        name: string;
        priceAdjustment: number;
    }[];
    dietaryInfo?: {
        vegetarian?: boolean;
        vegan?: boolean;
        glutenFree?: boolean;
        halal?: boolean;
    };
    preparationTime?: number;
    available?: boolean;
}

export interface VendorInfo {
    id: string;
    name: string;
    description: string;
    rating: number;
    image: string;
    features?: string;
    categories?: string;
    minOrder?: number;
    deliveryFee?: number;
  }