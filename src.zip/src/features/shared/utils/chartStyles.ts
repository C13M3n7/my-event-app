// src/features/shared/utils/chartStyles.ts
export const colors = {
    primary: 'rgba(59, 130, 246, 0.7)',
    primaryDark: 'rgba(59, 130, 246, 1)',
    secondary: 'rgba(16, 185, 129, 0.7)',
    secondaryDark: 'rgba(16, 185, 129, 1)'
  };