// Vendor Firestore ops (menus, orders)

// vendor-dashboard/orders (Vendor Order Tracking)
import type { Order, OrderStatus } from '$features/fnb/types/order';
import type { MenuItem, VendorInfo } from '$features/fnb/types/menu';

// Mock data - in a real app, this would come from Firestore
const mockMenuData: Record<string, MenuItem[]> = {
  'kfc': [
      {
          id: '1',
          title: 'Wicked Wings',
          image: '/images/wicked-wings.png',
          category: 'Food',
          price: 8.99,
          vendorId: 'kfc',
          vendorName: 'KFC',
          description: 'Spicy chicken wings with our signature seasoning',
          dietaryInfo: {
              halal: true
          }
      },
      {
          id: '2',
          title: 'Nuggets',
          image: '/images/nuggets.png',
          category: 'Food',
          price: 5.50,
          vendorId: 'kfc',
          vendorName: 'KFC',
          description: 'Crispy chicken nuggets',
          dietaryInfo: {
              halal: true
          }
      },
      {
          id: '3',
          title: 'Cola',
          image: '/images/cola.png',
          category: 'Drinks',
          price: 2.00,
          vendorId: 'kfc',
          vendorName: 'KFC'
      },
      {
          id: '4',
          title: 'Snack Plate',
          image: '/images/snack-plate.jpg',
          category: 'Food',
          price: 7.99,
          vendorId: 'kfc',
          vendorName: 'KFC',
          description: 'Chicken pieces with fries and drink',
          dietaryInfo: {
              halal: true
          }
      }
  ],
  'kantin': 
  [
      {
          id: 'k1',
          title: 'Kantin Kaffeine',
          image: '/images/F&B/Kantin/Kantin - Kantin Kaffeine.webp',
          category: 'Beverages',
          price: 10.00,
          vendorId: 'kantin',
          vendorName: 'Kantin At The Granary',
          description: '**ICE ONLY**',
          dietaryInfo: {
              halal: true
          }
      },
      {
          id: 'k2',
          title: 'Sarawak Teh C Special',
          image: '/images/F&B/Kantin/Kantin - Sarawak Teh C Special.webp',
          category: 'Beverages',
          price: 10.00,
          vendorId: 'kantin',
          vendorName: 'Kantin At The Granary',
          description: 'Espresso combined with vanilla-flavored syrup, milk, and caramel drizzle.',
          dietaryInfo: {
              halal: true
          }
      },
      {
          id: 'k3',
          title: 'Lemongrass Pandan',
          image: '/images/F&B/Kantin/Kantin - Lemongrass Pandan.webp',
          category: 'Beverages',
          price: 9.00,
          vendorId: 'kantin',
          vendorName: 'Kantin At The Granary',
          description: '',
          dietaryInfo: {
              halal: true
          }
      },
      {
          id: 'k4',
          title: 'French Fries with Green Dip Combo',
          image: '/images/F&B/Kantin/Kantin - Fries.webp',
          category: 'sides/snacks',
          price: 13.20,
          vendorId: 'kantin',
          vendorName: 'Kantin At The Granary',
          description: 'Combo includes one Citrus Breeze',
          dietaryInfo: {
              halal: true
          }
      },
      {
          id: 'k5',
          title: 'Sotong Bakar with Lepa Sauce Combo',
          image: '/images/F&B/Kantin/Kantin - Sotong Bakar with Lepa Sauce Combo.webp',
          category: 'sides/snacks',
          price: 41.10,
          vendorId: 'kantin',
          vendorName: 'Kantin At The Granary',
          description: 'Combo includes one Citrus Breeze',
          dietaryInfo: {
              halal: true
          }
      },
      {
          id: 'k6',
          title: 'Prawn Cucur Combo',
          image: '/images/F&B/Kantin/Kantin - Prawn Cucur Combo.webp',
          category: 'sides/snacks',
          price: 13.20,
          vendorId: 'kantin',
          vendorName: 'Kantin At The Granary',
          description: 'Combo includes one Citrus Breeze',
          dietaryInfo: {
              halal: true
          }
      },
      {
          id: 'k7',
          title: 'Kantin Kerabu Combo',
          image: '/images/F&B/Kantin/Kantin - Kerabu Combo.webp',
          category: 'Asian',
          price: 36.00,
          vendorId: 'kantin',
          vendorName: 'Kantin At The Granary',
          description: 'A dream dish come true. Butterfly pea blue rice, succulent ayam penyet with a generous serving of rempah, fried tempe, green papaya salad, salted egg, century agg and spicy kerabu sauce. What a combination! Combo includes one refreshing drink - Citrus Breeze.',
          dietaryInfo: {
              halal: true
          }
      },
      {
          id: 'k8',
          title: 'Kantin Nasi Lemak Combo',
          image: '/images/F&B/Kantin/Kantin - Nasi Lemak Combo.webp',
          category: 'Asian',
          price: 32.30,
          vendorId: 'kantin',
          vendorName: 'Kantin At The Granary',
          description: 'The classic national dish! Fragrant coconut milk rice, large fried chicken, fried ikan bilis, peanuts, fried egg, papadom, fresh cucumber slices and a dollop of addictive tangy sambal. Combo includes one refreshing drink - Citrus Breeze.',
          dietaryInfo: {
              halal: true
          }
      },
      {
          id: 'k9',
          title: 'Rainforest Fried Rice Combo',
          image: '/images/F&B/Kantin/Kantin - Rainforest Fried Rice Combo.webp',
          category: 'Asian',
          price: 27.90,
          vendorId: 'kantin',
          vendorName: 'Kantin At The Granary',
          description: 'The taste of Borneo: aromatic fried rice stir fry with local greens and herbs, deep fried cauliflower nuggets, crispy Shiitake mushrooms and a sprinkle of rainforest. Combo includes one refreshing drink - Citrus Breeze.',
          dietaryInfo: {
              halal: true
          }
      },
      {
          id: 'k10',
          title: 'Superdry Laksa Combo',
          image: '/images/F&B/Kantin/Kantin - Superdry Laksa Combo.webp',
          category: 'Asian',
          price: 26.40,
          vendorId: 'kantin',
          vendorName: 'Kantin At The Granary',
          description: 'No more spills! Dry Laksa beehoon, fresh prawns, fried chicken, sliced eggs, taugeh, lime and a touch of cilantro. Combo includes one refreshing drink - Citrus Breeze.',
          dietaryInfo: {
              halal: true
          }
      },
      {
          id: 'k11',
          title: 'Salmon Island Combo',
          image: '/images/F&B/Kantin/Kantin - Salmon Island Combo.webp',
          category: 'Mains',
          price: 70.40,
          vendorId: 'kantin',
          vendorName: 'Kantin At The Granary',
          description: 'The Norwegian Bornean Crossover! Pan-seared Norwegian salmon resting atop an exquisite island of wild roots mash, base, terung asam salsa and paired with manicai salad, a crunchy Kantan garnish, rounded off with a creamy tomato ocean finish.',
          dietaryInfo: {
              halal: true
          }
      },
      {
          id: 'k12',
          title: 'Angus Rib Eye Steak with Artisan Sauces',
          image: '/images/F&B/Kantin/Kantin - Angus Rib Eye Steak.webp',
          category: 'Mains',
          price: 149.60,
          vendorId: 'kantin',
          vendorName: 'Kantin At The Granary',
          description: 'Butter basted Angus Australian rib eye steak, with a side of fries and creamy manicai, featuring 3 artisan sauces: Brown Jus, Borneo Chimichurri and Lemongrass Béarnaise Combo includes one Citrus Breeze',
          dietaryInfo: {
              halal: true
          }
      },
      {
          id: 'k13',
          title: 'Wonderlamb with Asian Pesto Combo',
          image: '/images/F&B/Kantin/Kantin - Wonderlamb with Asian Pesto Combo.webp',
          category: 'Mains',
          price: 129.00,
          vendorId: 'kantin',
          vendorName: 'Kantin At The Granary',
          description: 'Juicy and tender roasted lamb rack, paired with sautéed local vegetables on a bed of wild roots mash. Served with Asian Pesto. Combo includes one Citrus Breeze',
          dietaryInfo: {
              halal: true
          }
      },
      {
          id: 'k14',
          title: 'Chargrilled Nanas Chicken Burger Combo',
          image: '/images/F&B/Kantin/Kantin - Chargrilled Nanas Chicken Burger Combo.webp',
          category: 'Mains',
          price: 46.95,
          vendorId: 'kantin',
          vendorName: 'Kantin At The Granary',
          description: 'Sweet and succulent chargrilled pineapple slice, large fried chicken, mayo, tantalising pineapple jam, coral lettuce and bombay onion in between buttered brioche bun, served with a side of fries. Combo includes one Citrus Breeze',
          dietaryInfo: {
              halal: true
          }
      },
      {
          id: 'k15',
          title: 'Kacangma Alfredo Pasta Combo',
          image: '/images/F&B/Kantin/Kantin - Kacangma Alfredo Pasta Combo.webp',
          category: 'Mains',
          price: 41.10,
          vendorId: 'kantin',
          vendorName: 'Kantin At The Granary',
          description: 'The ultimate Sarawakian fusion pasta. Kacangma\'s unique heartwarming flavours fused into a creamy experience you’ll fall in love with. Combo includes one Citrus Breeze',
          dietaryInfo: {
              halal: true
          }
      }
  ]
};

export async function updateOrderStatus(orderId: string, newStatus: OrderStatus): Promise<void> {
    // In a real app, this would call your backend API
    // For frontend-only, we'll simulate an API call with a delay
    return new Promise(resolve => {
      setTimeout(() => {
        console.log(`Order ${orderId} status updated to ${newStatus}`);
        resolve();
      }, 500);
    });
  }

  export const getVendorMenu = async (vendorId: string): Promise<MenuItem[]> => {
    try {
      await new Promise(resolve => setTimeout(resolve, 300)); // Simulate network delay
      
      if (!mockMenuData[vendorId]) {
        throw new Error('Vendor not found');
      }
      
      return mockMenuData[vendorId] || [];
    } catch (error) {
      console.error('Error fetching vendor menu:', error);
      return [];
    }
  };