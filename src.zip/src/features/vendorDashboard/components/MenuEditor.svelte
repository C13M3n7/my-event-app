<!-- CRUD interface for menu items -->
<!-- src/features/vendorDashboard/components/MenuEditor.svelte -->
<script lang="ts">
    import { createEventDispatcher } from 'svelte';
    import { v4 as uuidv4 } from 'uuid';
    import type { MenuItem } from '$features/fnb/types/menu';
  
    export let item: MenuItem | null = null;
    export let menuItems: MenuItem[] = [];
    const dispatch = createEventDispatcher();
  
    // Form data
    let formData = {
      title: '',
      description: '',
      price: 0,
      category: '',
      preparationTime: 15,
      dietaryInfo: {
        halal: false,
        vegetarian: false,
        vegan: false
      },
      image: null as File | null,
      imagePreview: '',
      available: true
    };
  
    // Track if form has been submitted (for validation)
    let formSubmitted = false;
    
    // Available categories
    const categories = [
      'Main Course',
      'Snacks and Sides',
      'Beverages',
      'Desserts',
      'Specials'
    ];
  
    // Initialize form
    $: if (item) {
      formData = {
        title: item.title,
        description: item.description || '',
        price: item.price,
        category: item.category || categories[0],
        preparationTime: item.preparationTime || 15,
        dietaryInfo: {
          halal: item.dietaryInfo?.halal || false,
          vegetarian: item.dietaryInfo?.vegetarian || false,
          vegan: item.dietaryInfo?.vegan || false
        },
        image: null,
        imagePreview: item.image || '',
        available: item.available ?? true
      };
    }
  
    // Handle image upload
    function handleImageUpload(event: Event) {
      const file = (event.target as HTMLInputElement).files?.[0];
      if (file) {
        if (file.size > 2 * 1024 * 1024) {
          alert('Image size should be less than 2MB');
          return;
        }
        formData.image = file;
        const reader = new FileReader();
        reader.onload = (e) => {
          formData.imagePreview = e.target?.result as string;
        };
        reader.readAsDataURL(file);
      }
    }
  
    // Check for duplicate menu item names
    function isDuplicate(name: string, currentId?: string): boolean {
      return menuItems.some(
        menuItem => menuItem.title.toLowerCase() === name.toLowerCase() && 
                   menuItem.id !== currentId
      );
    }
  
    // Validate form fields
    function validateField(field: string, value: any): string | null {
      switch (field) {
        case 'title':
          return !value ? 'Item name is required' : null;
        case 'price':
          return value <= 0 ? 'Price must be greater than 0' : null;
        case 'category':
          return !value ? 'Category is required' : null;
        case 'preparationTime':
          return value <= 0 ? 'Preparation time must be greater than 0' : null;
        default:
          return null;
      }
    }
  
    // Handle form submission
    function handleSubmit() {
      formSubmitted = true;
      
      // Validate all fields
      const errors = {
        title: validateField('title', formData.title),
        price: validateField('price', formData.price),
        category: validateField('category', formData.category),
        preparationTime: validateField('preparationTime', formData.preparationTime)
      };
  
      // Check if any errors exist
      if (Object.values(errors).some(error => error !== null)) {
        return;
      }
  
      if (isDuplicate(formData.title, item?.id)) {
        alert('A menu item with this name already exists. Please use a different name.');
        return;
      }
  
      const menuItem: MenuItem = {
        id: item?.id || uuidv4(),
        title: formData.title.trim(),
        description: formData.description.trim(),
        price: parseFloat(formData.price.toString()),
        category: formData.category,
        preparationTime: formData.preparationTime,
        dietaryInfo: {
          halal: formData.dietaryInfo.halal,
          vegetarian: formData.dietaryInfo.vegetarian,
          vegan: formData.dietaryInfo.vegan
        },
        image: formData.imagePreview,
        available: formData.available,
        vendorId: item?.vendorId || '' // Set from parent
      };
  
      if (item) {
        dispatch('update', menuItem);
      } else {
        dispatch('create', menuItem);
      }
      
      dispatch('close');
    }
  
    // Handle delete
    function handleDelete() {
      if (item && confirm('Are you sure you want to delete this menu item?')) {
        dispatch('delete', item.id);
        dispatch('close');
      }
    }
  </script>
  
   <!-- Main Modal -->
  <div class="fixed inset-0 z-100 overflow-y-auto">
    <div class="flex items-center justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
      <!-- Modal overlay -->
      <div class="menu-editor__modal fixed inset-0 transition-opacity" aria-hidden="true">
        <div class="menu-editor__backdrop absolute inset-0 bg-gray-500 opacity-75" on:click={() => dispatch('close')} />
      </div>
      
      <!-- Modal container -->
      <div class="menu-editor__modal relative inline-block align-bottom bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full z-[1002]">
        <!-- Modal content -->
        <div class="menu-editor__content inline-block align-bottom bg-white rounded-lg px-4 pt-5 pb-4 text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full sm:p-6">
          <h2 class="menu-editor__title text-xl font-semibold mb-4">
            {item ? 'Edit Menu Item' : 'Add New Menu Item'}
          </h2>
  
          <form on:submit|preventDefault={handleSubmit}>
            <!-- Name -->
            <div class="mb-4">
              <label for="title" class="block text-sm font-medium text-gray-700 mb-1">
                Item Name *
              </label>
              <input
                id="title"
                type="text"
                bind:value={formData.title}
                class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                class:border-red-300={formSubmitted && validateField('title', formData.title)}
              />
              {#if formSubmitted && validateField('title', formData.title)}
                <p class="mt-1 text-sm text-red-600">{validateField('title', formData.title)}</p>
              {/if}
            </div>
  
            <!-- Description -->
            <div class="mb-4">
              <label for="description" class="block text-sm font-medium text-gray-700 mb-1">
                Description
              </label>
              <textarea
                id="description"
                bind:value={formData.description}
                rows={3}
                class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
              />
            </div>
  
            <!-- Price -->
            <div class="mb-4">
              <label for="price" class="block text-sm font-medium text-gray-700 mb-1">
                Price *
              </label>
              <div class="relative rounded-md shadow-sm">
                <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <span class="text-gray-500 sm:text-sm">$</span>
                </div>
                <input
                  id="price"
                  type="number"
                  min="0.01"
                  step="0.01"
                  bind:value={formData.price}
                  class="pl-7 w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                  class:border-red-300={formSubmitted && validateField('price', formData.price)}
                />
              </div>
              {#if formSubmitted && validateField('price', formData.price)}
                <p class="mt-1 text-sm text-red-600">{validateField('price', formData.price)}</p>
              {/if}
            </div>
  
            <!-- Category -->
            <div class="mb-4">
              <label for="category" class="block text-sm font-medium text-gray-700 mb-1">
                Category *
              </label>
              <select
                id="category"
                bind:value={formData.category}
                class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                class:border-red-300={formSubmitted && validateField('category', formData.category)}
              >
                {#each categories as category}
                  <option value={category}>{category}</option>
                {/each}
              </select>
              {#if formSubmitted && validateField('category', formData.category)}
                <p class="mt-1 text-sm text-red-600">{validateField('category', formData.category)}</p>
              {/if}
            </div>
  
            <!-- Preparation Time -->
            <div class="mb-4">
              <label for="preparationTime" class="block text-sm font-medium text-gray-700 mb-1">
                Preparation Time (minutes) *
              </label>
              <input
                id="preparationTime"
                type="number"
                min="1"
                bind:value={formData.preparationTime}
                class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                class:border-red-300={formSubmitted && validateField('preparationTime', formData.preparationTime)}
              />
              {#if formSubmitted && validateField('preparationTime', formData.preparationTime)}
                <p class="mt-1 text-sm text-red-600">{validateField('preparationTime', formData.preparationTime)}</p>
              {/if}
            </div>
  
            <!-- Availability -->
            <div class="mb-4">
              <label class="block text-sm font-medium text-gray-700 mb-1">
                Availability
              </label>
              <div class="flex items-center">
                <input
                  id="available"
                  type="checkbox"
                  bind:checked={formData.available}
                  class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                />
                <label for="available" class="ml-2 block text-sm text-gray-700">
                  Available for order
                </label>
              </div>
            </div>
  
            <!-- Dietary Info -->
            <div class="mb-4">
              <label class="block text-sm font-medium text-gray-700 mb-2">
                Dietary Information
              </label>
              <div class="space-y-2">
                <div class="flex items-center">
                  <input
                    id="halal"
                    type="checkbox"
                    bind:checked={formData.dietaryInfo.halal}
                    class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                  />
                  <label for="halal" class="ml-2 block text-sm text-gray-700">
                    Halal
                  </label>
                </div>
                <div class="flex items-center">
                  <input
                    id="vegetarian"
                    type="checkbox"
                    bind:checked={formData.dietaryInfo.vegetarian}
                    class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                  />
                  <label for="vegetarian" class="ml-2 block text-sm text-gray-700">
                    Vegetarian
                  </label>
                </div>
                <div class="flex items-center">
                  <input
                    id="vegan"
                    type="checkbox"
                    bind:checked={formData.dietaryInfo.vegan}
                    class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                  />
                  <label for="vegan" class="ml-2 block text-sm text-gray-700">
                    Vegan
                  </label>
                </div>
              </div>
            </div>
  
            <!-- Image Upload -->
            <div class="mb-6">
              <label class="block text-sm font-medium text-gray-700 mb-2">
                Item Image
              </label>
              <div class="flex items-center">
                {#if formData.imagePreview}
                  <img
                    src={formData.imagePreview}
                    alt="Preview"
                    class="h-20 w-20 object-cover rounded-md mr-4"
                  />
                {:else}
                  <div class="h-20 w-20 bg-gray-200 rounded-md flex items-center justify-center text-gray-400 mr-4">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      class="h-8 w-8"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                    >
                      <path
                        stroke-linecap="round"
                        stroke-linejoin="round"
                        stroke-width="2"
                        d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"
                      />
                    </svg>
                  </div>
                {/if}
                <div>
                  <input
                    id="image-upload"
                    type="file"
                    accept="image/*"
                    on:change={handleImageUpload}
                    class="hidden"
                  />
                  <label
                    for="image-upload"
                    class="cursor-pointer bg-white py-2 px-3 border border-gray-300 rounded-md shadow-sm text-sm leading-4 font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                  >
                    {formData.imagePreview ? 'Change Image' : 'Upload Image'}
                  </label>
                  <p class="mt-1 text-xs text-gray-500">
                    JPG, PNG up to 2MB
                  </p>
                </div>
              </div>
            </div>
  
  
            <!-- Form Actions -->
            <div class="mt-5 sm:mt-6 sm:grid sm:grid-cols-2 sm:gap-3 sm:grid-flow-row-dense">
              <button
                type="submit"
                class="w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-blue-600 text-base font-medium text-white hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 sm:col-start-2 sm:text-sm"
              >
                {item ? 'Update Item' : 'Add Item'}
              </button>
              
              {#if item}
                <button
                  type="button"
                  on:click={handleDelete}
                  class="w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-red-600 text-base font-medium text-white hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500 sm:col-start-1 sm:text-sm"
                >
                  Delete Item
                </button>
              {:else}
                <button
                  type="button"
                  on:click={() => dispatch('close')}
                  class="mt-3 w-full inline-flex justify-center rounded-md border border-gray-300 shadow-sm px-4 py-2 bg-white text-base font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 sm:mt-0 sm:col-start-1 sm:text-sm"
                >
                  Cancel
                </button>
              {/if}
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>