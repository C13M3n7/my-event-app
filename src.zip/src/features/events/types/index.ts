// src/features/events/types/index.ts
export type { Event, EventTab } from './event';
export type { FestivalData, FestivalDay, SocialMedia, Organizer } from './festival';